'use client'

import { useState, useMemo } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { 
  MapPin, 
  Phone, 
  Clock, 
  Share2, 
  Heart, 
  MessageCircle, 
  TrendingUp,
  TrendingDown,
  Minus,
  Navigation,
  Copy,
  Check,
  ChevronRight,
  Star,
  Gift,
  Bell,
  Users,
  QrCode,
  Recycle,
  Leaf,
  Calendar
} from 'lucide-react'

// 回收站基本信息配置
const recyclingStation = {
  name: "绿源环保回收站",
  address: "北京市朝阳区望京街道阜通东大街6号院",
  phone: "13800138000",
  wechat: "lvyuan_recycle",
  businessHours: "08:00 - 20:00",
  coordinates: {
    lat: 40.0045,
    lng: 116.4735
  },
  description: "专业废品回收，上门服务，价格公道，诚信经营",
  rating: 4.8,
  reviewCount: 128
}

// 废品价格数据（模拟当日价格）
const priceData = [
  { category: "废金属", items: [
    { name: "废铜", price: 45.5, unit: "元/斤", trend: "up", change: "+0.5" },
    { name: "废铝", price: 8.2, unit: "元/斤", trend: "down", change: "-0.1" },
    { name: "废铁", price: 1.2, unit: "元/斤", trend: "stable", change: "0" },
    { name: "废钢", price: 1.5, unit: "元/斤", trend: "up", change: "+0.1" },
  ]},
  { category: "废纸类", items: [
    { name: "黄纸板", price: 0.85, unit: "元/斤", trend: "up", change: "+0.05" },
    { name: "书本报纸", price: 0.75, unit: "元/斤", trend: "stable", change: "0" },
    { name: "混合废纸", price: 0.45, unit: "元/斤", trend: "down", change: "-0.02" },
  ]},
  { category: "废塑料", items: [
    { name: "PET瓶", price: 2.8, unit: "元/斤", trend: "up", change: "+0.2" },
    { name: "HDPE塑料", price: 2.2, unit: "元/斤", trend: "stable", change: "0" },
    { name: "混合塑料", price: 0.8, unit: "元/斤", trend: "down", change: "-0.05" },
  ]},
  { category: "电子产品", items: [
    { name: "废旧手机", price: 15, unit: "元/台起", trend: "stable", change: "0" },
    { name: "废旧电脑", price: 50, unit: "元/台起", trend: "up", change: "+5" },
    { name: "废旧家电", price: 30, unit: "元/台起", trend: "stable", change: "0" },
  ]},
]

// 获取今日日期
const getTodayDate = () => {
  const today = new Date()
  const year = today.getFullYear()
  const month = String(today.getMonth() + 1).padStart(2, '0')
  const day = String(today.getDate()).padStart(2, '0')
  const weekDays = ['周日', '周一', '周二', '周三', '周四', '周五', '周六']
  const weekDay = weekDays[today.getDay()]
  return `${year}年${month}月${day}日 ${weekDay}`
}

export default function Home() {
  const [copied, setCopied] = useState(false)
  const [isFavorite, setIsFavorite] = useState(false)
  const currentTime = useMemo(() => getTodayDate(), [])

  // 一键拨号
  const handleCall = () => {
    window.location.href = `tel:${recyclingStation.phone}`
  }

  // 一键导航
  const handleNavigation = () => {
    const { lat, lng } = recyclingStation.coordinates
    const address = encodeURIComponent(recyclingStation.address)
    const name = encodeURIComponent(recyclingStation.name)
    
    // 判断设备类型，选择对应地图
    const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent)
    const isAndroid = /Android/.test(navigator.userAgent)
    
    if (isIOS) {
      // iOS 优先使用苹果地图
      window.location.href = `maps://maps.apple.com/?daddr=${lat},${lng}&dirflg=d`
    } else if (isAndroid) {
      // Android 使用高德地图
      window.location.href = `androidamap://route?sourceApplication=recycle&dname=${name}&dlon=${lng}&dlat=${lat}&dev=0`
    } else {
      // 其他设备使用百度地图网页版
      window.open(`https://map.baidu.com/dir/${address}`, '_blank')
    }
  }

  // 复制地址
  const handleCopyAddress = () => {
    navigator.clipboard.writeText(recyclingStation.address)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  // 分享功能
  const handleShare = async () => {
    const shareData = {
      title: recyclingStation.name,
      text: `${recyclingStation.name} - ${recyclingStation.description}\n地址：${recyclingStation.address}\n电话：${recyclingStation.phone}`,
      url: window.location.href
    }
    
    if (navigator.share) {
      try {
        await navigator.share(shareData)
      } catch (err) {
        console.log('分享取消')
      }
    } else {
      // 降级处理：复制分享内容
      navigator.clipboard.writeText(shareData.text + '\n' + shareData.url)
      alert('分享链接已复制到剪贴板')
    }
  }

  // 获取趋势图标
  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'up':
        return <TrendingUp className="w-3.5 h-3.5 text-green-500" />
      case 'down':
        return <TrendingDown className="w-3.5 h-3.5 text-red-500" />
      default:
        return <Minus className="w-3.5 h-3.5 text-gray-400" />
    }
  }

  // 获取趋势颜色
  const getTrendColor = (trend: string) => {
    switch (trend) {
      case 'up':
        return 'text-green-600'
      case 'down':
        return 'text-red-500'
      default:
        return 'text-gray-400'
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 to-white">
      {/* 顶部状态栏 */}
      <div className="bg-green-600 text-white px-4 py-2 text-xs flex justify-between items-center">
        <span className="flex items-center gap-1">
          <Calendar className="w-3.5 h-3.5" />
          {currentTime}
        </span>
        <span className="flex items-center gap-1">
          <Clock className="w-3.5 h-3.5" />
          营业中
        </span>
      </div>

      {/* 头部区域 - 回收站信息 */}
      <div className="bg-gradient-to-r from-green-600 to-green-500 text-white px-4 py-6 pb-16 relative">
        <div className="flex items-start gap-3">
          <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center shadow-lg">
            <img 
              src="/recycling-logo.png" 
              alt="回收站logo" 
              className="w-12 h-12 object-contain"
            />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <h1 className="text-xl font-bold truncate">{recyclingStation.name}</h1>
              <Badge variant="secondary" className="bg-green-400/30 text-white text-xs px-2 py-0.5">
                认证
              </Badge>
            </div>
            <p className="text-green-100 text-sm mb-2 line-clamp-1">{recyclingStation.description}</p>
            <div className="flex items-center gap-3 text-sm">
              <span className="flex items-center gap-1">
                <Star className="w-4 h-4 text-yellow-300 fill-yellow-300" />
                <span className="font-medium">{recyclingStation.rating}</span>
              </span>
              <span className="text-green-200">|</span>
              <span className="text-green-100">{recyclingStation.reviewCount}条评价</span>
            </div>
          </div>
        </div>

        {/* 快捷操作按钮 */}
        <div className="flex gap-3 mt-4">
          <Button 
            onClick={handleCall}
            className="flex-1 bg-white text-green-600 hover:bg-green-50 font-medium py-6 rounded-xl shadow-lg"
          >
            <Phone className="w-5 h-5 mr-2" />
            一键拨号
          </Button>
          <Button 
            onClick={handleNavigation}
            className="flex-1 bg-white text-green-600 hover:bg-green-50 font-medium py-6 rounded-xl shadow-lg"
          >
            <Navigation className="w-5 h-5 mr-2" />
            一键导航
          </Button>
        </div>
      </div>

      {/* 主内容区域 */}
      <div className="px-4 -mt-8 pb-24 space-y-4">
        {/* 联系信息卡片 */}
        <Card className="shadow-lg border-0 rounded-2xl overflow-hidden">
          <CardContent className="p-4">
            {/* 地址 */}
            <div className="flex items-start gap-3 pb-3">
              <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center flex-shrink-0">
                <MapPin className="w-5 h-5 text-green-600" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm text-gray-500 mb-1">地址</p>
                <p className="text-gray-800 font-medium">{recyclingStation.address}</p>
              </div>
              <Button 
                variant="ghost" 
                size="sm"
                onClick={handleCopyAddress}
                className="text-green-600 flex-shrink-0"
              >
                {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              </Button>
            </div>
            
            <Separator className="my-2" />
            
            {/* 电话和微信 */}
            <div className="flex items-center justify-between pt-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                  <Phone className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-500">电话</p>
                  <p className="text-gray-800 font-medium">{recyclingStation.phone}</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center">
                  <MessageCircle className="w-5 h-5 text-green-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-500">微信</p>
                  <p className="text-gray-800 font-medium">{recyclingStation.wechat}</p>
                </div>
              </div>
            </div>
            
            <Separator className="my-3" />
            
            {/* 营业时间 */}
            <div className="flex items-center gap-3 pt-2">
              <div className="w-10 h-10 rounded-full bg-orange-100 flex items-center justify-center">
                <Clock className="w-5 h-5 text-orange-600" />
              </div>
              <div>
                <p className="text-sm text-gray-500">营业时间</p>
                <p className="text-gray-800 font-medium">{recyclingStation.businessHours}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* 当日价格卡片 */}
        <Card className="shadow-lg border-0 rounded-2xl overflow-hidden">
          <CardHeader className="bg-gradient-to-r from-green-50 to-green-100/50 px-4 py-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-green-500 flex items-center justify-center">
                  <Recycle className="w-4 h-4 text-white" />
                </div>
                <CardTitle className="text-lg text-gray-800">今日回收价格</CardTitle>
              </div>
              <Badge variant="outline" className="bg-white text-green-600 border-green-200">
                实时更新
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <div className="divide-y divide-gray-100">
              {priceData.map((category, idx) => (
                <div key={idx} className="p-4">
                  <h3 className="text-sm font-medium text-gray-500 mb-3 flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-green-500"></span>
                    {category.category}
                  </h3>
                  <div className="space-y-2">
                    {category.items.map((item, itemIdx) => (
                      <div 
                        key={itemIdx} 
                        className="flex items-center justify-between py-2 px-3 bg-gray-50 rounded-lg"
                      >
                        <span className="text-gray-700">{item.name}</span>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-green-600 text-lg">
                            ¥{item.price}
                          </span>
                          <span className="text-gray-400 text-xs">{item.unit}</span>
                          <div className={`flex items-center gap-0.5 ${getTrendColor(item.trend)}`}>
                            {getTrendIcon(item.trend)}
                            <span className="text-xs">{item.change}</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* 私域运营 - 会员福利卡片 */}
        <Card className="shadow-lg border-0 rounded-2xl overflow-hidden bg-gradient-to-br from-green-500 to-green-600 text-white">
          <CardContent className="p-4">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center">
                <Gift className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="font-bold text-lg">会员专属福利</h3>
                <p className="text-green-100 text-sm">扫码加入会员，享更多优惠</p>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-2 mt-4">
              <div className="bg-white/10 rounded-xl p-3 text-center">
                <Leaf className="w-6 h-6 mx-auto mb-1" />
                <p className="text-xs">环保积分</p>
              </div>
              <div className="bg-white/10 rounded-xl p-3 text-center">
                <Bell className="w-6 h-6 mx-auto mb-1" />
                <p className="text-xs">价格提醒</p>
              </div>
              <div className="bg-white/10 rounded-xl p-3 text-center">
                <Users className="w-6 h-6 mx-auto mb-1" />
                <p className="text-xs">专属客服</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* 服务特色 */}
        <Card className="shadow-lg border-0 rounded-2xl overflow-hidden">
          <CardHeader className="px-4 py-3">
            <CardTitle className="text-lg text-gray-800 flex items-center gap-2">
              <Star className="w-5 h-5 text-yellow-500" />
              服务特色
            </CardTitle>
          </CardHeader>
          <CardContent className="px-4 pb-4">
            <div className="grid grid-cols-2 gap-3">
              <div className="flex items-center gap-2 p-3 bg-green-50 rounded-xl">
                <Check className="w-5 h-5 text-green-600" />
                <span className="text-sm text-gray-700">上门回收</span>
              </div>
              <div className="flex items-center gap-2 p-3 bg-blue-50 rounded-xl">
                <Check className="w-5 h-5 text-blue-600" />
                <span className="text-sm text-gray-700">称重准确</span>
              </div>
              <div className="flex items-center gap-2 p-3 bg-orange-50 rounded-xl">
                <Check className="w-5 h-5 text-orange-600" />
                <span className="text-sm text-gray-700">价格透明</span>
              </div>
              <div className="flex items-center gap-2 p-3 bg-purple-50 rounded-xl">
                <Check className="w-5 h-5 text-purple-600" />
                <span className="text-sm text-gray-700">现结付款</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* 快捷服务入口 */}
        <Card className="shadow-lg border-0 rounded-2xl overflow-hidden">
          <CardContent className="p-4">
            <div className="grid grid-cols-4 gap-4">
              <button 
                onClick={() => alert('预约回收功能开发中...')}
                className="flex flex-col items-center gap-2"
              >
                <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center">
                  <Calendar className="w-6 h-6 text-green-600" />
                </div>
                <span className="text-xs text-gray-600">预约回收</span>
              </button>
              <button 
                onClick={() => alert('价格提醒功能开发中...')}
                className="flex flex-col items-center gap-2"
              >
                <div className="w-12 h-12 rounded-full bg-orange-100 flex items-center justify-center">
                  <Bell className="w-6 h-6 text-orange-600" />
                </div>
                <span className="text-xs text-gray-600">价格提醒</span>
              </button>
              <button 
                onClick={() => alert('积分商城功能开发中...')}
                className="flex flex-col items-center gap-2"
              >
                <div className="w-12 h-12 rounded-full bg-purple-100 flex items-center justify-center">
                  <Gift className="w-6 h-6 text-purple-600" />
                </div>
                <span className="text-xs text-gray-600">积分商城</span>
              </button>
              <button 
                onClick={() => alert('在线客服功能开发中...')}
                className="flex flex-col items-center gap-2"
              >
                <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center">
                  <MessageCircle className="w-6 h-6 text-blue-600" />
                </div>
                <span className="text-xs text-gray-600">在线客服</span>
              </button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* 底部操作栏 */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-4 py-3 safe-area-inset-bottom">
        <div className="flex items-center justify-between gap-4 max-w-lg mx-auto">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setIsFavorite(!isFavorite)}
              className="flex flex-col items-center gap-1"
            >
              <Heart 
                className={`w-6 h-6 ${isFavorite ? 'fill-red-500 text-red-500' : 'text-gray-400'}`} 
              />
              <span className="text-xs text-gray-500">收藏</span>
            </button>
            <button 
              onClick={handleShare}
              className="flex flex-col items-center gap-1"
            >
              <Share2 className="w-6 h-6 text-gray-400" />
              <span className="text-xs text-gray-500">分享</span>
            </button>
          </div>
          <div className="flex-1 flex gap-2">
            <Button 
              onClick={handleCall}
              variant="outline"
              className="flex-1 border-green-500 text-green-600 hover:bg-green-50"
            >
              <Phone className="w-4 h-4 mr-1" />
              拨打电话
            </Button>
            <Button 
              onClick={handleNavigation}
              className="flex-1 bg-green-600 hover:bg-green-700 text-white"
            >
              <Navigation className="w-4 h-4 mr-1" />
              去导航
            </Button>
          </div>
        </div>
      </div>

      {/* 安全区域适配 */}
      <style jsx global>{`
        .safe-area-inset-bottom {
          padding-bottom: max(0.75rem, env(safe-area-inset-bottom));
        }
        .line-clamp-1 {
          display: -webkit-box;
          -webkit-line-clamp: 1;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }
      `}</style>
    </div>
  )
}
