import type { Metadata, Viewport } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  viewportFit: "cover",
  themeColor: "#16a34a",
};

export const metadata: Metadata = {
  title: "绿源环保回收站 - 废品回收信息展示平台",
  description: "专业废品回收，上门服务，价格公道，诚信经营。查看当日回收价格，一键导航、一键拨号，便捷高效的废品回收服务。",
  keywords: ["废品回收", "环保回收", "再生资源", "上门回收", "回收价格", "金属回收", "纸类回收", "塑料回收"],
  authors: [{ name: "绿源环保" }],
  icons: {
    icon: "/recycling-logo.png",
    apple: "/recycling-logo.png",
  },
  openGraph: {
    title: "绿源环保回收站",
    description: "专业废品回收，价格公道，上门服务",
    type: "website",
    locale: "zh_CN",
  },
  appleWebApp: {
    capable: true,
    statusBarStyle: "black-translucent",
    title: "绿源回收",
  },
  formatDetection: {
    telephone: true,
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="zh-CN" suppressHydrationWarning>
      <head>
        <meta name="format-detection" content="telephone=yes" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
      </head>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
